<?php $__env->startSection('content'); ?>
<?php $provider = app('App\Helpers\Helper'); ?>
 
  <!-- Begin Page Content -->
  <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">School Dashboard</h1>
    </div>

    <!-- Content Row -->
    <div class="row">

      <!-- Earnings (Monthly) Card Example -->
      

      <!-- Earnings (Monthly) Card Example -->
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Staff</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($teacher); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-users fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Earnings (Monthly) Card Example -->
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Today Present</div>
                <div class="row no-gutters align-items-center">
                  <div class="col-auto">
                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e($present); ?></div>
                  </div>
                  <div class="col">
            
                  </div>
                </div>
              </div>
              <div class="col-auto">
                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Pending Requests Card Example -->
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Today on Leave</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($leave); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-rocket fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Today absent</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($absent); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 
    <!-- Content Row -->

    <div class="row">

      <!-- Area Chart -->
      <div class="col-xl-8 col-lg-8">
        <div class="card shadow mb-4">
          <!-- Card Header - Dropdown -->
          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Upload Attendance</h6>
            
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <div class="chart-area">
                <?php echo Form::open(array('route' => 'school.attendance.import', 'id' => 'school.attendance.import', 'class' => 'form-horizontal bucket-form',  'onsubmit' => 'return confirmSubmit()', 'files' => true ,  'method' => 'post' )); ?>

                <?php echo csrf_field(); ?>
                <input type="file" name="import_file" />
                    <button type="submit"  class="btn btn-primary">
                                  <span class="icon text-white-100">
                                      <i class="fas fa-upload"></i>
                                  </span>
                                  <span class="text ">Upload</span>
                              </button> 
                              
                    <?php echo Form::close(); ?>

                    
              <input type="hidden" name="p_fld" id="p_fld" value="<?php echo e($p); ?>" >
              <input type="hidden" name="a_fld" id="a_fld" value="<?php echo e($absent); ?>" >
              <input type="hidden" name="l_fld" id="l_fld" value="<?php echo e($leave); ?>" >
              <input type="hidden" name="m_fld" id="m_fld" value="<?php echo e($mis); ?>" >

     
                    <div class="h-100 py-4">   
                      <div id="clock" class="dark">
                        <div class="display">
                          <div class="weekdays"></div>
                          <div class="ampm"></div>
                          <div class="alarm"></div>
                          <div class="digits" > </div>
                          <div class="todate">
                            <center> 
                              <span id="todate" style="font-family: 'Orbitron', sans-serif; text-align:center;"></span>       
                            </center>
                            </div>
                        </div>
                      </div>  
                    </div>
         
            </div>
          </div>
        </div>
      </div>

      <!-- Pie Chart -->
      <div class="col-xl-4 col-lg-4">
        <div class="card shadow mb-4">
          <!-- Card Header - Dropdown -->
          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Attendance Status</h6>
            
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <div class="chart-pie pt-4 pb-2">
              <canvas id="myPie" ></canvas>
            </div>
            <div class="mt-4 text-center small">
            
            <?php if(!empty($present)): ?>
              <span class="mr-2">
                <i class="fas fa-circle text-primary"></i> Present
              </span>
              <?php endif; ?>
              
              <?php if(!empty($absent)): ?>
              <span class="mr-2">
                <i class="fas fa-circle text-danger"></i> Absent
              </span>
              <?php endif; ?>
              
              <?php if(!empty($leave)): ?>
              <span class="mr-2">
                <i class="fas fa-circle text-info"></i> On leave
              </span>
              <?php endif; ?>
              <?php if(!empty($mis)): ?>
              <span class="mr-2">
                <i class="fas fa-circle text-warning"></i> MIS
              </span>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Content Row -->
    <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Attendance Report</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
        
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                    <th>Sl</th>
                      <th>Name</th>
                      <th> Code</th>
                      <th>Shift Start</th>
                      <th>Shift End</th>
                      <th>In Time</th>
                      <th>Out Time</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                   
                  <tbody>
                  <?php if(!empty($results)): ?> 
                  <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <tr> 
                    <td><?php echo e($k+1); ?></td>
                      <td><?php echo e($v->emp->first_name); ?> <?php echo e($v->emp->last_name); ?>

                       
                      </td>
                      <td><?php echo e($v->unique_id); ?></td>
                      <td><?php echo e($provider->dateformatcontrol($v->shift_start)); ?></td>
                      <td><?php echo e($provider->dateformatcontrol($v->shift_end)); ?></td>
                      <td>
                   
                        <?php if( $v->attendance_type == "2"): ?>
                        <center> <i class="fa fa-flag text-danger"  data-toggle="tooltip" data-placement="top"  title="Absent"></i></center>
                        <?php elseif( $v->attendance_type == "3"): ?>
                        <center> <i class="fa fa-flag text-info" data-toggle="tooltip" data-placement="top"  title="On Leave"></i></center>
                        <?php else: ?> 
                          <?php echo e(date('H:i:s', strtotime($v->in_time ))); ?>

                        <?php endif; ?> 
                      </td>
                      <td>
                      <?php if(($v->upload_status=='0' && empty($v->out_time)) && $v->attendance_type == "1"): ?> 
                      <center> 
                        <span class="blinking palybtn"  data-toggle="tooltip" data-placement="top"  title="Shift Running!"><i class=" fa fa-play-circle text-success"></i></span>
                        <span class="over blinking" data-toggle="tooltip" data-placement="top"  title="Shift Over, Please Upload the attendance!"> 
                          <i class="fas fa-upload text-danger"></i>
                      </span> 
                      </center>
                      <?php elseif( empty($v->out_time)  && ($v->attendance_type == "2" || $v->attendance_type == "3")): ?>
                        <?php if( $v->attendance_type == "2"): ?>
                        <center><i class="fa fa-flag text-danger"  data-toggle="tooltip" data-placement="top"  title="Absent"></i></center>
                        <?php elseif( $v->attendance_type == "3"): ?>
                        <center><i class="fa fa-flag text-info"  data-toggle="tooltip" data-placement="top"  title="On Leave"></i></center>
                        <?php endif; ?> 
                      <?php elseif(( $v->upload_status == '1' && empty($v->out_time)) && $v->attendance_type == "4"): ?> 
                      <center><i class="fa fa-battery-quarter text-warning"  data-toggle="tooltip" data-placement="top"  title="Remarks: <?php echo e($v->remarks); ?>"></i></center>
                      <?php else: ?> 
                        <?php echo e(date('H:i:s', strtotime($v->out_time ))); ?> 
                      <?php endif; ?>
                      </td>
                      <td>
                       <?php if( $v->attendance_type == "1"): ?>
                       <i class="text-success"  data-toggle="tooltip" data-placement="top"  title="Present">Present</i>
                       <?php elseif( $v->attendance_type == "2"): ?>
                       <i class="text-danger"  data-toggle="tooltip" data-placement="top"  title="Absent">Absent</i>
                       <?php elseif( $v->attendance_type == "3"): ?>
                       <i class="text-info"  data-toggle="tooltip" data-placement="top"  title="On Leave">On Leave</i>
                       <?php else: ?> 
                       <i class="text-warning" data-toggle="tooltip" data-placement="top"  title="Remarks: <?php echo e($v->remarks); ?>">MIS</i>
                       <?php endif; ?>
                      </td>
                    </tr> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  </tbody>
                </table>
                  
              </div>
            </div>
          </div>
  </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('school.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tams\resources\views/school/home.blade.php ENDPATH**/ ?>
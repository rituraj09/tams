<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Teacher</h1>

<div class="row">
    <div class="col-lg-12"> 
        <div class="card shadow mb-4">   
            <div class="card-header py-3">
                <div class="row no-gutters align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary col mr-2">Add Teacher</h6>
                        <div class="pull-right col-auto"> <span class="text-danger">* fields are mandatory!</span></div>
                </div>
            </div>              
            <div class="card-body">
            <?php echo $__env->make('include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
           
            <?php echo Form::open(array('route' => 'school.teacher.save', 'id' => 'school.teacher.save', 'class' => 'form-horizontal bucket-form',  'onsubmit' => 'return confirmSubmit()', 'files' => true)); ?>

            
            <?php echo $__env->make('school.teacher._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
            <div class="form-group">
                <div class="row">
                    <?php echo Form::label('', '', array('class' => 'col-md-3 control-label')); ?>

                        <div class="col-md-5">
                        <button type="submit"  class="btn btn-success btn-icon-split ">
                            <span class="icon text-white-100">
                                <i class="fas fa-arrow-right"></i>
                            </span>
                            <span class="text ">Submit</span>
                        </button> 
                        </div>
                    </div>
            </div> 
            <?php echo Form::close(); ?> 
            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('school.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tams\resources\views/school/teacher/create.blade.php ENDPATH**/ ?>
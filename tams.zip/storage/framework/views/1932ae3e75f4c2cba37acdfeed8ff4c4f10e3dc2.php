<div class="form-group <?php echo e($errors->has('school_name') ? 'has-error' : ''); ?>">
    <div class="row">
        <?php echo Form::label('name', 'School Name :', array('class' => 'col-md-2 control-label')); ?>

        <div class="col-md-5">
            <?php echo Form::text('name', null, ['class' => 'form-control', 'id' => 'name', 'placeholder' => ' ', 'autocomplete' => 'off', 'required' => 'true']); ?>

        </div>
        <?php echo $errors->first('name', '<span class="text-danger">:message</span>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('school_code') ? 'has-error' : ''); ?>">
    <div class="row">
        <?php echo Form::label('code', 'School Code :', array('class' => 'col-md-2 control-label')); ?>

        <div class="col-md-5">
            <?php echo Form::text('code', null, ['class' => 'form-control', 'id' => 'code', 'placeholder' => ' ', 'autocomplete' => 'off', 'required' => 'true']); ?>

        </div>
        <?php echo $errors->first('code', '<span class="text-danger">:message</span>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <div class="row">
        <?php echo Form::label('email', 'Email :', array('class' => 'col-md-2 control-label')); ?>

        <div class="col-md-5">
            <?php echo Form::email('email', null, ['class' => 'form-control', 'id' => 'email', 'placeholder' => ' ', 'autocomplete' => 'off', 'required' => 'true']); ?>

        </div>
        <?php echo $errors->first('email', '<span class="text-danger">:message</span>'); ?>

    </div>
</div>
 
<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <div class="row">
        <?php echo Form::label('password', 'Password :', array('class' => 'col-md-2 control-label')); ?>

        <div class="col-md-5">
                <input type="password" name="password" class="form-control" placeholder="" required>
          </div>
        <?php echo $errors->first('password', '<span class="text-danger">:message</span>'); ?>

    </div>
</div>
<div class="form-group ">
    <div class="row">
        <?php echo Form::label('confirm_password', 'Confirm Password :', array('class' => 'col-md-2 control-label')); ?>

        <div class="col-md-5">
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>           
        </div> 
    </div>
</div>
 <?php /**PATH C:\xampp\htdocs\tams\resources\views/admin/school/_form.blade.php ENDPATH**/ ?>
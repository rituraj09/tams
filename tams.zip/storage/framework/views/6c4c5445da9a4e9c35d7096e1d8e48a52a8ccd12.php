 

<?php if(session('class')=='success'): ?> 
        <div class="alert alert-class alert-success"> 
        <button type="button" class="close" data-dismiss="alert">×</button>
       <?php echo e(session('msg')); ?>

        </div> 
<?php endif; ?>
 
<?php if(session('class')=='failed'): ?> 
        <div class="alert alert-class alert-danger"> 
        <button type="button" class="close" data-dismiss="alert">×</button>
       <?php echo e(session('msg')); ?>

        </div> 
<?php endif; ?>
<?php if(session('error')): ?> 
    <div class="alert alert-class alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php echo e(session('error')); ?>

    </div> 
<?php endif; ?> <?php /**PATH C:\xampp\htdocs\tams\resources\views/include/message.blade.php ENDPATH**/ ?>
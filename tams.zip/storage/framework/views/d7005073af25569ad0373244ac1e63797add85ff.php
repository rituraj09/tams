<?php $__env->startSection('content'); ?>

<div class="row">
      <div class="col-xl-12 col-lg-12">
      <div class="card shadow   mb-4">
          <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Upload Attendance</h6>
          </div>
          <div class="card-body">
          <?php echo $__env->make('include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
          <?php echo Form::open(array('route' => 'school.attendance.import', 'id' => 'school.attendance.import', 'class' => 'form-horizontal bucket-form',  'onsubmit' => 'return confirmSubmit()', 'files' => true ,  'method' => 'post' )); ?>

          <?php echo csrf_field(); ?>
          <input type="file" name="import_file" />
              <button type="submit"  class="btn btn-primary">
                            <span class="icon text-white-100">
                                <i class="fas fa-upload"></i>
                            </span>
                            <span class="text ">Upload</span>
                        </button> 
                        
              <?php echo Form::close(); ?>

          </div>
      </div>  
      </div> 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('school.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tams\resources\views/school/attendance/attendance_upload.blade.php ENDPATH**/ ?>
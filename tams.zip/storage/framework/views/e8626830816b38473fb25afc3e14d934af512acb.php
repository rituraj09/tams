<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Teacher</h1>

<div class="row">
    <div class="col-lg-12"> 
        <div class="card shadow mb-4">   
            <div class="card-header py-3">
                <div class="row no-gutters align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary col mr-2">View Teacher</h6>
        
                </div>
            </div>              
            <div class="card-body">
            <?php echo $__env->make('include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                <div class="row">
                    <div class="col-md-12">     
                        <div class="table-responsive">               
                        <table class="table  table-bordered"  cellspacing="0">
                        <thead>
                        <tr>
                            <th width="8%"> Sl No</th>
                            <th width="15%">Biometric Code</th> 
                            <th >Full Name</th>
                            <th >Mobile Number</th>
                            <th >Employee type</th> 
                            <th  width="10%">Transactions</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="#"><?php echo e($k+1); ?></a></td>
                                <td><a href="#"><?php echo e($v->unique_id); ?></a></td>
                                <td>  <?php echo e($v->first_name); ?> <?php echo e($v->last_name); ?> </td> 
                                <td><?php echo e($v->phone); ?></td>
                                <td> <?php echo e($v->employee_types->name); ?></td>
                                
                                                         
                                <td>
                                    <a href="#" class="btn btn-primary btn-sm">View</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('school.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tams\resources\views/school/teacher/view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php $provider = app('App\Helpers\Helper'); ?>

<h1 class="h3 mb-4 text-gray-800">Preview Attendance</h1>

<div class="row">
    <div class="col-lg-12"> 
    <?php echo Form::open(array('route' => 'school.attendance.savedata', 'id' => 'school.attendance.savedata', 'class' => 'form-horizontal bucket-form',  'onsubmit' => 'return confirmSubmit()', 'files' => true ,  'method' => 'post' )); ?>

          <?php echo csrf_field(); ?>
          <?php $nodata=0; ?>
        <div class="card shadow mb-4">   
            <div class="card-header py-3">
                <div class="row no-gutters align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary col mr-2">Attendance for the date: <?php echo e($date); ?></h6>
                    <div class="pull-right col-auto">
                     <span class="text-danger">All text fields are mandatory!</span>
                    </div>
           
                </div>
            </div>              
            <div class="card-body">
            <?php echo $__env->make('include.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>             
                <div class="row">
                    <div class="col-md-12">     
                        <div class="table-responsive">        
                        <?php echo e(Form::hidden('school_id', $school_id , array('id' => 'school_id'))); ?>     
                        <?php echo e(Form::hidden('date', $date, array('id' => 'date'))); ?>        
                        <small> <table class="table  table-bordered"  cellspacing="0">
                        <thead>
                        <tr>
                            <th width="6%"> Sl No</th>
                            <th >Name</th> 
                            <th >Biometric Code</th>
                            <th >Shift Start</th>
                            <th >Shift End</th> 
                            <th >In Time</th> 
                            <th >Out Time</th> 
                            <th  >Status </th>
                            <?php if($provider->getattand($date, $school_id) > 0): ?> 
                            <th  >Reason</th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($c= $k+1); ?></td>
                                <?php $uid= $v['emp_code'] ?> 
                                <?php $emp_id= $provider->getname($uid, $school_id)->id    ?>
                                <?php echo e(Form::hidden('sl[]', $c, array('id' => 'sl'))); ?>

                                <?php echo e(Form::hidden('unique_id[]', $emp_id, array('id' => 'unique_id'))); ?>

                                <?php echo e(Form::hidden('shift_start[]', $v['shift_start'], array('id' => 'shift_start'))); ?>

                                <?php echo e(Form::hidden('shift_end[]', $v['shift_end'], array('id' => 'shift_end'))); ?>

                                <?php echo e(Form::hidden('in_time[]', $v['in_time'], array('id' => 'in_time'))); ?>

                                <?php echo e(Form::hidden('out_time[]', $v['out_time'], array('id' => 'out_time'))); ?>  
                                <td>
                                    <?php if(empty($provider->getname($uid, $school_id))): ?>
                                    Null
                                      <?php $nodata=1 ?>
                                    <?php else: ?>
                                    <?php echo e($provider->getname($uid, $school_id)->first_name); ?>  <?php echo e($provider->getname($uid, $school_id)->last_name); ?>

                                    <?php endif; ?>
                                </td>
                                <td>  <?php echo e($v['emp_code']); ?> </td> 
                                <td> <?php echo e($shift_start); ?> 
                                </td>
                                <td> <?php echo e($shift_end); ?><br> 
                               
                                </td>
                                
                                <td>
                                <?php if($provider->getattand($date, $school_id) > 0): ?>
                                <?php $attndid = $provider->getattand($date, $school_id);
                                
                                $attndtype = $provider->getAttendanceType($emp_id, $attndid)->attendance_type;
                                ?>
                                    <?php if(empty($v['in_time']) && $attndtype == "2"): ?>  
                                        <i class="fa fa-flag text-danger"><i>
                                     
                                    <?php elseif(empty($v['in_time']) && $attndtype == 3): ?>  
                                        On Leave
                                    <?php else: ?>
                                        <?php echo e($v['in_time']->format('H:i:s')); ?>

                                    <?php endif; ?>
                                <?php else: ?> 
                                    <?php if(empty($v['in_time']) ): ?>  
                                        <i class="fa fa-flag text-danger"><i> 
                                    <?php else: ?>
                                        <?php echo e($v['in_time']->format('H:i:s')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                                 </td>
                                <td> 
                                
                                <?php if($provider->getattand($date, $school_id) > 0): ?>
                                    <?php if($attndtype == 3): ?>
                                            On Leave
                                    <?php else: ?>
                                        <?php if(empty($v['out_time'] )): ?>
                                        <i class="fa fa-flag text-danger"><i>
                                    
                                        <?php else: ?>
                                        <?php echo e($v['out_time']->format('H:i:s')); ?>

                                        <?php endif; ?> 
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if(!empty($v['out_time'] )): ?> 
                                        <?php echo e($v['out_time']->format('H:i:s')); ?>

                                    <?php endif; ?>
                                <?php endif; ?>
                                </td>       
                                <td>
                                
                                <?php if($provider->getattand($date, $school_id) == 0): ?>

                                    <?php if($v['status']=='A'): ?>
                                        <select name="attendance_type[]" id="attendance_type">
                                            <option value="2" >Absent</option>
                                            <option value="3"  >Leave</option>
                                        </select>
                                    <?php else: ?>     
                                        Present
                                         <?php echo e(Form::hidden('attendance_type[]', 1, array('id' => 'attendance_type'))); ?>  
                                    
                                    <?php endif; ?>
                                    
                                <?php elseif($provider->getattand($date, $school_id) > 0): ?> 

                                    <?php if($v['status']=='P'): ?>
                                         Present
                                         <?php echo e(Form::hidden('attendance_type[]', 1, array('id' => 'attendance_type'))); ?> 

                                    <?php elseif($v['status']=='A'): ?>
                                        <select name="attendance_type[]" id="attendance_type">
                                            <option value="2" <?php echo e($provider->getAttendanceType( $emp_id, $attndid)->attendance_type == 2 ? 'selected' : ''); ?>>Absent</option>
                                            <option value="3" <?php echo e($provider->getAttendanceType( $emp_id, $attndid)->attendance_type == 3 ? 'selected' : ''); ?>>Leave</option>
                                        </select>
                                    <?php else: ?>                                          
                                    <?php echo e(Form::hidden('attendance_type[]', 4, array('id' => 'attendance_type'))); ?> 
                                                MIS
                                    <?php endif; ?>
                                  <?php endif; ?>
                                </td>
                                <?php if($provider->getattand($date, $school_id) > 0): ?> 
                                <td>
                                
                                    <?php if(empty($v['out_time']) && !empty($v['in_time'])): ?>
                                    <textarea id="remarks" class="form-control" placeholder="Reason must require!" name="remarks[]" required rows="3"></textarea>
                                    <?php else: ?>
                                    <?php echo e(Form::hidden('remarks[]', '', array('id' => 'remarks'))); ?>

                                    <?php endif; ?>
                                </td>
                                <?php else: ?> 
                                    <?php echo e(Form::hidden('remarks[]', '', array('id' => 'remarks'))); ?>

                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table></small>
                       
                        
                        </div>
                    </div>

                </div>  
                <?php if($provider->getattand($date, $school_id) == '0' && $provider->firsthalf($date) == '1'): ?>
                <div class="row">
                     <div class="col-md-12  py-3">
                         <div class="pull-right col-md-3">   

                         <textarea id="reason" class="form-control" placeholder="Reason of late upload must require!" name="reason" required rows="3"></textarea>    
                         </div> 
                     </div>
                     </div>
                <?php else: ?>
                    <?php echo e(Form::hidden('reason', '', array('id' => 'reason'))); ?>

                <?php endif; ?>
                <?php if($nodata==1): ?>
                <div class="row">
                     <div class="col-md-12  py-3">
                         <div class="pull-right col-md-5">   
                         <div class="alert alert-class alert-danger">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                           New Teacher's record(s) has not added to the database!
                        </div> 
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                    <div class="row">
                        <div class="col-md-12   py-3">
                            <div class="pull-right col-auto">
                                    <a href="<?php echo e(route('school.attendance.upload')); ?>"    class="btn  btn-sm btn-warning btn-icon-split ">
                                        <span class="icon text-white-100">
                                                    <i class="fas fa-arrow-left"></i>
                                                </span>
                                                <span class="text ">Back</span>
                                    </a>
                                    <?php if($nodata==0): ?>
                                    <button type="submit"  class="btn btn-success btn-sm btn-icon-split ">
                                            <span class="icon text-white-100">
                                                <i class="fas fa-save"></i>
                                        </span>
                                        <span class="text ">Submit</span>
                                    </button> 
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
 
 
<?php echo $__env->make('school.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tams\resources\views/school/attendance/attendance_view.blade.php ENDPATH**/ ?>